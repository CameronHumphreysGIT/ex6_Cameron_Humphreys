Cameron Humphreys 101162528
https://github.com/CameronHumphreysGIT/ex6_Cameron_Humphreys